package com.guitar.db.repository;

public interface ModelJpaRepositoryCustom {
	void aCustomMethod();
}

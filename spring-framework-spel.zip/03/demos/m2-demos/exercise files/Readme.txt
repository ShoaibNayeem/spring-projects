How to use the Exercise files
------------------------------
1. Order - Add this java class to your spel-demo Spring Boot project and write the relevant SpEL expressions
                         in the commented locations to wire it's properties.
2. applicationContext.xml - Add this to your spel-demo-xml Spring Boot project and write the relevant SpEL expressions
                         in the commented locations.

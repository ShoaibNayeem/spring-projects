package com.example.speldemoxml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpelDemoXmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpelDemoXmlApplication.class, args);
	}

}

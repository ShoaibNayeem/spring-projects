package com.example.speldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpelDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.speldemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpelDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpelDemoApplication.class, args);
	}

}

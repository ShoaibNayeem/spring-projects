How to use the Exercise files
------------------------------
1. AppExpressionParser - Add this java class to your spel-demo Spring Boot project and write the relevant SpEL expressions
                         in the commented locations.
2. User - Add this java class to your spel-demo Spring Boot project and write the relevant SpEL expressions
                         in the commented locations to wire it's properties.
